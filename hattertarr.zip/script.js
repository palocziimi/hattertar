//atviteli
function Eredmeny(){
    var csuszka = document.getElementById("atvitelisebesseg");
    document.querySelector("p").innerHTML = csuszka.value.toString();
}

function Szamol(){
    var kapacitas = parseInt(document.getElementById("kapacitas").value);
    var kapmennyiseg= document.getElementById("kapvalaszto").value;
    var csuszka = parseInt(document.getElementById("atvitelisebesseg").value);
    var csuszkasebesseg= document.getElementById("atvitelivalaszto").value;

    if (kapmennyiseg=="Gb") {
        kapacitas*=1000;
    }
    else if (kapmennyiseg=="Tb"){
        kapacitas*=1000000;
    }


    if(csuszkasebesseg=="Kbps"){
        csuszka/=1000;
    }
    else if(csuszkasebesseg=="mbps"){
        csuszka/=8;
    }
    else if(csuszkasebesseg=="Gbps"){
        csuszka*=1000;
    }

    document.querySelector("div").innerHTML = Math.round(kapacitas/csuszka).toString()+" másodperc";





}